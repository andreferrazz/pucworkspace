#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Aluno {
    char *nome;
    char *matricula;
    float n1;
    float n2;
    float n3;
} Aluno;

void print_aluno(struct Aluno aluno) {
    printf("Aluno{ ");
    printf("nome: \"%s\", ", aluno.nome);
    printf("matricula: \"%s\", ", aluno.matricula);
    printf("n1: %.2f, ", aluno.n1);
    printf("n2: %.2f, ", aluno.n2);
    printf("n3: %.2f", aluno.n3);
    printf(" }\n");
}

char** splitString(char* str) {
    char** arr = malloc(5 * sizeof(char*)); 
    char *token = strtok(str, " ");
    int i = 0;
    arr[i++] = token;

    while (token != NULL)
    {
        printf("%s\n", token);
        token = strtok(NULL, "-");
        arr[i++] = token;
    }

    return arr;
}

struct Aluno fromString(char *str) {
    char** parts = splitString(str);
    struct Aluno *aluno = malloc(sizeof(Aluno));
    aluno->nome = parts[0];
    aluno->matricula = parts[1];
    aluno->n1 = atof(parts[2]);
    aluno->n2 = atof(parts[3]);
    aluno->n3 = atof(parts[4]);
    return *aluno;
}

struct Aluno *get_alunos() {
    FILE *file = fopen("alunos.csv", "r");

    char row[100];
    int size;

    if (fgets(row, 100, file)) {
        size = atoi(row);
    }

    struct Aluno *alunos = malloc(size * sizeof(Aluno));

    for (int i = 0; i < size; i++) {
        if (fgets(row, 100, file)) {
            alunos[i] = fromString(row);
        }
    }

    fclose(file);

    return alunos;
}

int main() {
    struct Aluno *aluno = get_alunos();
    print_aluno(aluno[0]);
}